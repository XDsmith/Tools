# Digital Team Operating Model

**Owner:** [name] · **Status:** Draft for team review · **Last updated:** July 2026

---

## Why this document exists

Digital sits in the middle of eleven partner groups — Business Banking, Retail Banking, Loan Center, Branch, Customer Support, Product, Marketing, Technology, MarTech, Data, and AI. Each has plans that touch the digital experience, and each needs our help at different times for different things. Without a shared way of working, requests arrive ad hoc, priorities get set by whoever asked loudest, and our own strategic work gets crowded out.

This model gives everyone — our team and our partners — one answer to four questions: how work gets to us, how we decide what to do, how we do it, and how we stay aligned with the rest of the bank.

---

## The model at a glance

1. **Work comes in one door and gets a type and a size.** Intake form → 30-minute call → classified as Assessment, Strategy, or Launch → sized S/M/L/XL → into the backlog.
2. **We decide together on a rhythm.** Annually with lines of business to align roadmaps. Quarterly with executives to commit capacity.
3. **Pods do the work and show it constantly.** Capped capacity per pod, weekly report-out, a deliverable, workshop, or demo to the partner every one to two weeks.

Everything below is detail inside these three moves.

---

## Roles

| Role | In this model |
|------|---------------|
| **Strategist** | Owns the model and the backlog. Sizes work (with pod leads), runs the quarterly commitment review, approves concurrency exceptions, receives weekly report-outs, leads Strategy projects. |
| **Product Owner (PO)** | Leads and owns Launches — scope, priorities, ship decisions. Supports Assessments and Strategies for continuity, so the person who owns the Launch was in the room when it was framed and decided. |
| **Business Analyst (BA)** | Business, user, and facilitation focused. Leads Assessment facilitation and research. Builds the service blueprints, journey maps, and scenarios. Primary facilitator across all three project types. |
| **Business Systems Analyst (BSA)** | Technical analyst. Writes development, UAT, and regression test stories — converting scenarios into testable stories is the core of the job. Owns integration mapping detail, leads UAT. |
| **UX Designer (UXD)** | Rapid prototyping, competitive analysis, user workflows, screens, scenario development with the BA, and presentation building. Leads the Design phase. |
| **UX Content (UXC)** | Content and copy: interface content, error and edge-state language, customer communications. In every Design phase and every Ship phase. |
| **Developers (.NET × 3)** | Blazor and React. Lead Build and Integrate on Launches. Consulted during Define for feasibility. |
| **Requesting partner (sponsor + working contact)** | Every project has a named sponsor (accountable, attends readouts and go/no-go) and a working contact (available weekly). No sponsor, no project. |
| **Technology & PMO** | Capacity gatekeepers. No quarter is committed until Technology confirms build/integration capacity and PMO confirms the portfolio view. Technology also co-decides in Strategy decision phases and leads coordination in Integrate. |
| **Data, AI, MarTech** | Dual role. As **requesters**, they come through intake like anyone else. As **delivery partners**, they join pods for specific phases — Data in Discover and measurement, AI in recommendation/decisioning builds, MarTech in Ship. The intake call determines which hat they're wearing. |
| **Branch & Customer Support** | Frontline partners. Requesters through intake, and standing participants in Discover (they see customer struggle first), scenario validation (a scenario that doesn't survive the branch or the phones isn't done), and Ship readiness. |

*Why dual role is explicit:* without it, a Data request gets confused with a Data dependency, and partner groups end up inside projects with no defined engagement. Naming the two hats at intake settles it per project.

---

## How we collaborate

Default to making together, not presenting to. Partners co-create the deliverables in working sessions — framing problems, clustering evidence, sketching concepts, scoring options — using structured methods (LUMA and similar) so sessions produce artifacts, not just discussion. A presentation is reserved for genuine decision gates: the Recommend readout, the executive roadmap readout, the go/no-go. Everything else is a session where the partner holds a marker.

*Why:* co-created deliverables don't need to be sold afterward. A partner who clustered the evidence themselves doesn't dispute the recommendation; a sponsor who sketched in the design studio defends the design in rooms we're not in.

### Scenarios: the thread through everything

A scenario is a short, concrete story of a specific person accomplishing something real: *a small-business owner with an existing checking account applies for a line of credit from her phone on a Saturday; a Customer Support rep helps a customer who abandoned a wire transfer halfway.* Scenarios are how we make sure we **build the right thing** and **build it right**:

- **Born in Discover/Define.** BA and UXD write scenarios from research evidence and journey maps — grounded in real customers and real employees, validated with Branch and Customer Support.
- **Drive Design.** Every design must satisfy its scenarios. A screen that can't be walked through as a story isn't done.
- **Become the tests.** The BSA converts scenarios into development, UAT, and regression test stories. The thing we imagined in week two is literally the thing we test in month five.
- **Gate the launch.** Go/no-go includes walking the core scenarios end to end in the real system.

*Why scenarios:* requirements lists describe pieces; scenarios describe outcomes. A project can pass every requirement and fail its scenario — scenarios are how we catch that before customers do. They're also the shared language: a branch manager, a developer, and an executive can all read the same scenario and mean the same thing.

---

## Project types

Every piece of work is one of three types. The type tells you what the project produces, what "done" means, and who it loads. Each phase below lists its deliverable (required and optional contents), its collaboration activities (required and optional), and who participates. The deliverable is the exit gate: the phase is done when the deliverable exists and its required collaboration has happened.

### Assessment — produces a decision

Answers: *should we do this at all?* Output is a go/no-go or a scoped recommendation — never a build commitment. Typical size: S–M (two to eight weeks).

**Frame** *(~1 week for an M)*
- **Deliverable — Problem Brief.** Required: problem statement in the requester's language, who is affected, decision criteria (what evidence would make this a yes or a no), definition of success. Optional: initial hypotheses, known constraints, prior attempts.
- **Collaboration.** Required: framing session with sponsor and working contact — Abstraction Laddering to find the right altitude on the problem, Statement Starters ("How might we…") to convert it into an answerable question, and co-written decision criteria before anyone leaves the room. Optional: Stakeholder Mapping if the affected parties aren't obvious; Rose/Thorn/Bud on the current state to surface what the requester already knows.
- **Who:** BA facilitates, PO in the room for continuity, sponsor and working contact make the problem statement theirs.

*Why criteria come first:* decision criteria written before evidence gathering can't be rationalized after.

**Discover** *(~2–4 weeks for an M)*
- **Deliverable — Evidence Pack.** Required: research findings (customer or employee), relevant data pull with baseline numbers, compliance/risk read, draft scenarios grounded in the evidence. Optional: vendor scan and demo notes, competitive analysis (UXD), rough cost picture.
- **Collaboration.** Required: interviews or contextual inquiry — with Branch and Customer Support as first stops when the problem touches the frontline; midpoint sensemaking session, Affinity Clustering the emerging evidence *with* the requester so the patterns are found together rather than reported later. Optional: requester joins interviews as a second observer (the fastest empathy-builder we have); Experience Diagramming of the current journey with the people who live it; vendor demos with the requester in the room running Rose/Thorn/Bud immediately after.
- **Who:** BA leads and facilitates, BSA supports the data and technical evidence, Data joins as delivery partner if a pull is needed, requester working contact is in the research, not waiting on it.

**Evaluate** *(~1 week)*
- **Deliverable — Options Analysis.** Required: evidence weighed against the Frame criteria, impact vs. effort for each option, risks. Optional: build vs. buy comparison, dependency notes.
- **Collaboration.** Required: evaluation session with the requester — options placed on an Importance/Difficulty Matrix together, Visualize the Vote where the criteria leave room for judgment. The requester scores alongside us; the matrix is the deliverable's spine. Optional: Technology and BSA in the room for the difficulty axis.
- **Who:** full pod plus requester working contact; BA facilitates, PO synthesizes.

**Recommend** *(~1 week)*
- **Deliverable — Recommendation Memo.** Required: go/no-go with rationale traced to the criteria; if go — the scoped shape of the Launch it spawns, including swag size, its core scenarios, and known dependencies. Optional: suggested quarter, suggested pod.
- **Collaboration.** Required: readout with requester sponsor — this one *is* a presentation, because it's a decision gate. By this point the sponsor's team helped frame the question, cluster the evidence, and score the options, so the readout confirms rather than persuades. Optional: pre-read to Technology if the go has integration weight.
- **Who:** BA and PO present (UXD builds the presentation), sponsor decides to accept, Strategist confirms the size.

*Why the memo scopes the Launch:* the Launch enters the backlog already half-defined — scenarios included — so its Define phase starts warm, and the PO who will own it was there for all of it.

### Strategy — produces direction

Answers: *what's the target state and how do we get there?* The pursuit is already decided; the output is decisions and a sequenced path that Launches execute. Typical size: M–L (one to four months).

**Current State** *(~2–3 weeks for an L)*
- **Deliverable — Current State Assessment.** Required: capability inventory, architecture snapshot (with Technology), service blueprint or journey map of the current experience, top pain points with evidence. Optional: competitive analysis (UXD), baseline metrics (Data).
- **Collaboration.** Required: interviews or contextual inquiry with each partner group the strategy touches — Branch and Customer Support included whenever the strategy touches customers; then a cross-group synthesis workshop, Experience Diagramming the current state and Rose/Thorn/Bud on it, with the partner groups in the room building the map. Optional: Fly-on-the-Wall observation where the work happens (branch, back office, call center).
- **Who:** BA leads the blueprint/journey work and facilitates, BSA and Technology contribute the architecture view, partner groups co-build the current-state map.

**Target State** *(~2–4 weeks)*
- **Deliverable — Target State Definition.** Required: the north star articulated concretely enough to make decisions against, guiding principles, success measures, target-state scenarios. Optional: rapid prototype of a signature moment (UXD), a vision narrative for executive audiences.
- **Collaboration.** Required: target-state working session with sponsoring executives and affected partner groups — Creative Matrix to generate the possibility space, Concept Posters to make candidate futures concrete, Visualize the Vote to converge. Participants sketch; nobody watches slides. Optional: Cover Story mock-up for strategies that need an executive-grade narrative; a second divergent studio if the first converges too fast.
- **Who:** Strategist leads, UXD facilitates the studio and prototypes the concepts, BA writes the target-state scenarios, sponsor and partner groups generate and choose.

*Why a workshop, not a readout:* a target state that partners helped shape survives contact with their roadmaps.

**Options & Decisions** *(~2–3 weeks)*
- **Deliverable — Decision Record.** Required: options considered, decision made, rationale, build vs. buy where relevant. Optional: vendor scorecards, cost model.
- **Collaboration.** Required: decision workshop with Technology — options co-scored on a weighted matrix built from the target-state principles, Importance/Difficulty Matrix for sequencing tradeoffs; AI and Data join where decisioning or data architecture is in scope. The Decision Record is written in the room, not after it. Optional: vendor finalist demos scored live with Rose/Thorn/Bud; Buy-a-Feature when scope must be cut and stakeholders each want everything.
- **Who:** Strategist leads and ratifies, Technology architecture co-decides, BSA carries the technical detail.

*Why deliberation lives here:* Launches that relitigate architecture mid-flight stall. The Decision Record is what they point to instead.

**Roadmap** *(~1–2 weeks)*
- **Deliverable — Sequenced Roadmap.** Required: the Launches (and further Assessments) that close the gap, dependencies between them, rough phasing, capacity implications. Optional: funding ask, adoption/measurement plan.
- **Collaboration.** Required: sequencing session with PMO and Technology — Bull's-Eye Diagramming (now / next / later) done together on the wall, so capacity constraints shape the sequence in the room rather than breaking it afterward; then the executive readout, a genuine presentation gate. Optional: share-back session with the partner groups interviewed in Current State — they gave the evidence, they see where it landed.
- **Who:** Strategist facilitates the sequencing and presents the readout (UXD builds it), PMO and Technology co-sequence, PO in the room for continuity into the Launches it spawns.

### Launch — produces a live capability

Answers: *ship the thing.* Decision and direction already exist; this project contains everything from requirements to rollout. Typical size: L–XL (a quarter to a year). Rough shape for planning: Define and Design are the first third, Build and Integrate the middle, Ship the final stretch — meaning BA/BSA/UXD/UXC load the front of a Launch months before the developers touch it.

**Define** *(~15–20% of the project)*
- **Deliverable — Requirements Pack.** Required: the core scenarios (refined from the Assessment or Strategy that gated this Launch, validated with Branch and Customer Support), journey map or service blueprint of the future state, requirements, configuration decisions for the vendor platform, integration map (what data moves between vendor, core, and digital banking), vendor gap analysis, compliance and risk requirements. Optional: current-process maps, entitlement model.
- **Collaboration.** Required: future-state Experience Diagramming with the partner group — the flow drawn together before it's written as requirements; scenario validation session with Branch and Customer Support; vendor discovery sessions with Rose/Thorn/Bud run on the out-of-box demo (the gap analysis falls out of the thorns); What's on Your Radar with the partner to force scope priorities early; Technology feasibility review. Optional: contextual walkthrough of the back-office process the capability touches.
- **Who:** BA leads the journey, blueprint, and scenarios and facilitates; BSA owns the integration map and begins writing development stories from the scenarios; PO owns scope; vendor and Technology at the table.

**Design** *(~15–20%, overlaps Define's tail)*
- **Deliverable — Approved Designs.** Required: user workflows, screens, content and copy (UXC), error and edge-state language, rapid prototype, where the experience deviates from vendor defaults and why — all walkable against the core scenarios. Optional: competitive analysis of how peers solve the same moments, tested prototype findings.
- **Collaboration.** Required: design studio with the partner group early — everyone sketches (Creative Matrix or 6-8-5 rounds), UXD synthesizes into the prototype; structured critique sessions thereafter (Rose/Thorn/Bud, not "any thoughts?"); scenario walkthrough — the design is walked end to end as each scenario before sign-off from PO and sponsor. Optional but strongly recommended for anything customer-facing: think-aloud testing of the prototype with customers or frontline staff, partner group observing live — watching someone struggle ends design debates that meetings can't.
- **Who:** UXD leads (prototyping, workflows, testing), UXC owns content and copy, BA keeps designs tied to scenarios and requirements, partner group sketches and critiques rather than approves-by-email.

**Build** *(~30–40%)*
- **Deliverable — Working increments.** Required: demo-able functionality at every demo cadence, development stories traceable to scenarios, test coverage on our side. Optional: feature-flagged early releases to internal users.
- **Collaboration.** Required: demo to the partner every two weeks — no exceptions, this is what keeps long projects funded — with structured feedback captured in the room (Rose/Thorn/Bud on what was shown, so the demo produces input rather than nods). Optional: vendor build syncs weekly; partner working contact in sprint reviews.
- **Who:** developers lead our side, vendor configures theirs, BSA writes and grooms the stories, BA/PO clear business questions daily.

**Integrate** *(~15–20%)*
- **Deliverable — End-to-end tested capability.** Required: UAT and regression test stories (BSA, derived from the scenarios), integration test results across every seam (vendor ↔ core ↔ digital banking), defect log with resolutions, UAT sign-off from the partner group. Optional: performance and failover results.
- **Collaboration.** Required: UAT sessions with partner-group testers — Branch and Customer Support test the scenarios they validated in Define — run think-aloud style, so we capture confusion as well as defects; vendor and Technology coordination standups. Optional: ops dry-run with back office, walking the real workflow end to end before cutover.
- **Who:** BSA leads UAT and regression, developers and Technology run integration, vendor on call, partner group tests, BA triages confusion vs. defect.

*Why Integrate is its own phase:* on vendor projects this is where timelines die — it runs at the vendor's and the core's pace, not ours. Naming it keeps the risk visible.

**Ship** *(~10–15%)*
- **Deliverable — Launch Package.** Required: end-to-end scenario walkthrough results in the production-ready system, cutover plan, rollout sequencing (pilot → segments → full), employee readiness materials for Branch and Customer Support, customer communications (UXC), monitoring and rollback plan, success measures with baselines. Optional: adoption campaign brief handed to Marketing/MarTech.
- **Collaboration.** Required: pre-mortem with the full launch group ("it's 60 days post-launch and this failed — why?") — the rollback plan and readiness gaps come out of it; go/no-go review with sponsor and Strategist, gated on the core scenarios passing end to end; launch readiness working session with Marketing, MarTech, Branch, Customer Support, and partner-group operations. Optional but recommended: 30-day retrospective run as Rose/Thorn/Bud with the same group — it feeds sizing calibration and next year's planning.
- **Who:** PO leads, BA facilitates the pre-mortem, UXC owns customer communications with Marketing, MarTech joins as delivery partner, Branch and Customer Support confirm frontline readiness, sponsor and Strategist make the go call.

---

## Intake

Any team requesting our help fills out a short form, then we hold a 30-minute call.

The form asks five things: what problem are you trying to solve, who is affected, what outcome do you want, when do you need it, and what's driving that timing.

*Why a form and a call:* the form filters — it forces the requester to articulate a problem rather than a solution, and gives us enough to prepare. The call clarifies — thirty minutes of conversation surfaces what a form never will. The call also settles whether Data, AI, or MarTech are requesting or partnering. Together they produce enough to classify and size without a discovery project.

Every request gets one of three answers: **yes** (typed, sized, into the backlog), **not now** (into the backlog, unprioritized, revisited quarterly), or **no** (with rationale — often "this needs an Assessment first," which is itself a yes to a smaller thing).

*Why an explicit no:* silence kills trust in an intake process faster than rejection does.

**The expedite path.** The only way around the quarterly gate. A request qualifies only with a regulatory deadline, an active customer-impacting defect, or a dated executive commitment. The Strategist decides. One expedite in flight at a time; pulling one in ejects something of equal size from the quarter, and the trade is named to both sponsors. Expedites are logged and counted at the quarterly review.

*Why the eject and the count:* an expedite without a cost is just queue-jumping, and a rising expedite count means planning is failing — the fix is the planning, not faster jumping.

---

## Sizing

Every item gets a swag size at intake, set by the Strategist and pod leads as a consistent small group.

| Size | Rough duration | Typical shape |
|------|---------------|---------------|
| S | 2–3 weeks | A small Assessment, a design-only ask, a contained enhancement |
| M | 4–10 weeks | A full Assessment, a focused Strategy, a small Launch |
| L | A quarter, give or take | A full Strategy, a typical Launch |
| XL | Up to a full year | A platform Launch (origination, servicing, identity) |

*Why swag sizing:* precision at intake is false precision. A size and a type are enough to plan a quarter; detailed estimation happens inside the project. *Why a consistent sizing group:* sizing is where politics hide. The same few people sizing everything keeps XL meaning XL.

---

## The backlog

One list. Everything sized and typed — partner requests from intake and our own strategic roadmap items sit in the same list and compete on the same terms.

*Why one list:* two backlogs means the strategic work always loses to the urgent request, or the reverse. One list forces the tradeoff into the open, where the quarterly review can arbitrate it.

---

## Where the work lives: Jira

One Jira project, one backlog, two Kanban boards. Every card carries five fields: **Type** (Assessment / Strategy / Launch), **Size**, **Sponsor**, **Pod**, **Partner group**.

**Work item hierarchy:**

- **Epic = the project.** One epic per Assessment, Strategy, or Launch; epics are the cards on the boards. The epic description carries the problem statement, sponsor, size, and — for Launches — the core scenarios.
- **Story = work that produces something a partner or teammate consumes.** In Assessments and Strategies: each phase deliverable and each required collaboration session is a story, so the column exit is checkable. In Launches: Define/Design artifacts, the development stories the BSA writes from scenarios, and the UAT and regression stories derived from the same scenarios — linked, so the spine *scenario → dev story → test story* is traceable in Jira.
- **Task = supporting work nothing partner-facing comes from directly** — recruiting participants, data pull requests, session prep. Tasks (or subtasks) keep the story list honest.
- The test: *would it show up in a weekly report-out or partner deliverable?* Story. *In service of one that will?* Task.
- **Requirements** [placeholder — decision pending]: if formal requirement-level traceability is needed by Technology or compliance, requirements become their own linked item type under Launch epics; otherwise the Requirements Pack lives as a document on the epic and the scenario spine carries traceability.

**Board 1 — Assessment & Strategy.** Both types share the same rhythm — understand, explore, decide, deliver — so they share four working columns:

| Column | Assessment phase | Strategy phase |
|--------|-----------------|----------------|
| Understand | Frame | Current State |
| Explore | Discover | Target State |
| Decide | Evaluate | Options & Decisions |
| Deliver | Recommend | Roadmap |

**Board 2 — Launch.** Ready → Define → Design → Build → Integrate → Ship → Done. Define and Design overlap in practice; the card sits in whichever phase is currently the bottleneck, and the stories underneath carry the finer grain.

Board rules:

- **Column exit = phase exit.** A card moves right only when the phase deliverable exists and its required collaboration has happened. The phase definitions above are the column policies.
- **Ready is gated.** Cards enter Ready only at the quarterly commitment review. Nothing jumps the gate.
- **WIP limits are the pod caps.** Working columns carry WIP limits derived from pod capacity; the concurrency rule (an XL owner takes nothing larger than an M without the Strategist) is board policy even though Jira won't enforce it.
- **Intake answers are visible.** *Not now* = stays in the backlog, labeled, revisited quarterly. *No* = closed as Won't Do with the rationale in a comment — the explicit no, on the record.
- **The handoff is literal.** When a Recommendation Memo says go, it spawns a new epic on the Launch board — sized, scenarios attached, sponsor named — entering the backlog for the next quarterly review.

*Why two boards over one:* Assessments and Strategies flow through different phases than Launches, and their pace differs by an order of magnitude — a six-week Assessment and a year-long platform Launch on the same board makes both unreadable. Two boards, one backlog: the work is visible in its own rhythm, but it competes in one place.

---

## Planning rhythms

### Annual — roadmap alignment with lines of business
Once a year, we meet with each partner group — Business Banking, Retail Banking, Loan Center, Branch, Customer Support, Product, Marketing, Technology, MarTech, Data, AI: we share what we plan for the coming year, they share theirs. We're looking for three things: **collaboration** (their initiative needs our capability, or ours needs their data), **conflict** (two groups changing the same experience, or competing for the same Technology capacity), and **gaps** (things nobody has claimed).

Output: next year's strategic items enter the backlog, and PMO and Technology get the demand signal early enough to plan against.

*Why annual:* conflicts found in January cost a conversation. Conflicts found in October cost a quarter.

### Quarterly — commitment review with executives
Each quarter, we present what we're pulling in next: the items, their types and sizes, and the capacity math. Disagreements about priority and total capacity get argued here — not mid-quarter.

**Technology and PMO are the capacity gatekeepers.** A quarter is only committable when three numbers clear: pod capacity (our people), Technology capacity (build and integration), and the PMO portfolio view (nothing else in the bank collides). Our pods can staff a Launch that Technology can't build — committing on one number is how quarters fail.

---

## Pods

The team works in pods: Digital team members paired with standing counterparts in the partner groups they serve. The same people work together across projects, so context compounds instead of resetting.

Each pod has a capacity cap in points. Two rules:

1. **Concurrency rule:** anyone carrying an XL takes nothing larger than an M without a conversation with the Strategist.
2. **Capacity is visible:** pods report committed vs. available points weekly.
3. **Blocked work escalates on a clock:** blocked cards are flagged on the board with the blocking party named and surfaced in the weekly report-out. Blocked more than 2 weeks, the Strategist takes it to the counterpart leader; more than 4 weeks, an off-cycle session with both sponsors decides — unblock, rescope, or return to the backlog. Pod capacity freed by a block pulls the next S or M.

*Why the clock:* the only alternative governance moment is quarterly, and a project can die of quiet blockage in less time than that. The clock makes stalling visible and owned.

*Why pods:* relationships are the actual delivery mechanism. A BA who knows Business Banking's operations doesn't re-learn the domain every project. *Why the concurrency rule:* XLs die quietly when their owners get pulled into everything else.

---

## Cadence and visibility

Two rhythms, non-negotiable:

- **Weekly report-out** to the Strategist: progress, blockers, capacity.
- **Partner-facing deliverable, workshop, or demo every one to two weeks**, per the collaboration activities named in each phase above — Assessments and Strategies tend toward workshops, Launches toward demos.

*Why:* a year-long project with nothing to show goes dark, and dark projects lose sponsorship. Constant visible motion is what keeps an XL funded through month eight.

---

## How it fits together

A request from Retail Banking arrives through intake. The call reveals it's really a question, not a build — it's classified Assessment, sized M, backlogged. At quarterly review, executives agree to pull it in. The BA facilitates Frame → Discover → Evaluate → Recommend over six weeks, with the PO alongside for continuity — Problem Brief in week one, Customer Support interviews and an evidence-clustering workshop with Retail at midpoint, draft scenarios in the Evidence Pack, Recommendation Memo at the end. The recommendation is go, and the memo scopes the Launch at L with its core scenarios attached. Next quarterly review commits it — after Technology confirms integration capacity and PMO clears the portfolio. The same PO now owns the Launch: BA refines the scenarios and blueprint in Define, Branch validates them, UXD prototypes and UXC writes the content in Design, the BSA turns the scenarios into development and UAT stories, developers build, Customer Support tests the scenarios they validated, and the go decision is gated on those scenarios passing end to end. MarTech joins at Ship to run the adoption campaign. At the next annual session, the shipped capability shows up in our roadmap share-out with 30-day adoption numbers attached.

Every piece of the model appears once in that paragraph. That's the whole system.

---

## What we still calibrate through use

Three things this document deliberately leaves loose, to be hardened after a few quarters of running:

1. **Point values per pod** — set an initial cap, adjust after two quarters of actuals.
2. **Sizing calibration** — the duration bands above are starting points; recalibrate against real projects, using 30-day post-launch reviews as the feedback loop.
3. **The Assessment → Launch handoff** — default is auto-entry to the backlog at the size the Recommendation Memo assigns; revisit if that inflates the backlog.

*Why leave these loose:* operating models fail when they're over-specified before first contact with real work. The structure is fixed; the tuning is earned.

# Fiserv XD Add-On Launch Playbook

**Status:** Working document
**Owner:** Digital Product & Experience
**Worked example:** SavvyMoney Credit Sense
**Last reviewed:** _[date]_

---

## 1. Purpose and scope

This document defines the repeatable process for attaching a vendor-delivered or internally built add-on to the Fiserv XD digital banking platform. It exists so that each launch inherits a known sequence of gates, owners, and decision criteria rather than reconstructing them.

An *add-on* is any capability that attaches to XD and is consumed by customers or staff: a partner-delivered service (e.g., Credit Sense via SavvyMoney), a new module, or a discrete feature that integrates with the platform's data, entitlement, or presentation layers.

Scope excludes routine configuration changes and content-only updates that introduce no new integration, no new data flow, and no new customer-facing commitment.

---

## 2. How to use this document

Not every add-on warrants the full sequence. Assign a tier at intake; the tier sets the depth of review.

| Tier | Trigger | Rigor |
|---|---|---|
| **Full** | New third-party integration, new customer data flow, or credit/lending/regulated content | All gates, all reviews mandatory |
| **Standard** | Internally built feature touching existing data contracts | All gates; risk review scoped to delta |
| **Fast lane** | Configuration or presentation change on an already-governed add-on | Gates 0, 4, 5 only |

Credit Sense is **Full tier**: third-party integration, new credit-data ingestion, and consumer-facing credit content.

---

## 3. Roles and decision rights

The defining characteristic of an XD add-on is that accountability spans three parties who each control only part of the system. The playbook's central purpose is to remove ambiguity at the seams between them.

| Party | Owns |
|---|---|
| **Digital (internal)** | Customer experience, disclosures and copy, eligibility logic, success definition, launch decision |
| **Vendor (e.g., SavvyMoney)** | Add-on functionality, data accuracy, service availability, rate/offer sourcing |
| **Fiserv** | XD integration model, certification path, entitlement and authentication, platform stability |

For each launch, complete a RACI that assigns — by name — the owner of: the data contract, the rate/offer update mechanism, rendering fidelity inside XD, incident response at each seam, and the go/no-go decision. The most common failure mode is not technical; it is an unassigned seam.

---

## 4. The gated lifecycle

Each gate has an owner, an entry condition, and an explicit go/no-go. A gate is not passed until its exit criteria are met and recorded.

### Gate 0 — Intake and qualification
**Owner:** Digital Product
**Exit criteria:** Candidate scored against strategic fit, demand signal, business impact, and risk exposure; tier assigned; sponsor and accountable owner named.

### Gate 1 — Discovery
**Owner:** Digital Product + UX
**Exit criteria:** Experience reviewed; customer communications mapped; data points to ingest identified; consuming systems determined; eligibility and threshold logic defined.

> **Credit Sense:** Complete. Discovery workshops reviewed the experience, mapped communications, identified data points to ingest, and determined the consuming systems. Product-eligibility and credit-band thresholds were facilitated in workshop.

### Gate 2 — Design and integration standards
**Owner:** Digital + Fiserv implementation contact
**Exit criteria:** Integration conforms to XD's model — entitlement, authentication, data contract, and rendering. Design-system and accessibility conformance confirmed. Fiserv certification requirements documented as fixed checkpoints.

> **Action:** Confirm Fiserv's formal certification gates with the implementation contact and insert them here as named checkpoints. These are inherited constraints, not internally defined ones.

### Gate 3 — Risk, compliance, and vendor governance
**Owner:** Digital + Risk/Compliance/Legal
**Exit criteria:** Vendor due diligence current; data handling and privacy reviewed; security assessment complete; consumer-disclosure and fair-lending review passed on all credit-adjacent content.

> **Credit Sense:** This gate governs the pre-launch items still open — product copy, product CTA, disclosures, loan attributes, and MIP. These are compliance artifacts, not only UX artifacts, because the feature displays credit information and pre-qualified offers. The credit-band thresholds and eligibility logic feed the offer determination a fair-lending review will examine. Designate which items are hard gates before any customer exposure.
>
> _Define MIP explicitly in this document so the term is unambiguous for future launches._

### Gate 4 — Build and test
**Owner:** Digital + Engineering + Vendor
**Exit criteria:** Functional, integration, UAT, and accessibility testing passed. Rate/offer sourcing verified end to end. Rollback plan documented.

### Gate 5 — Staged rollout
**Owner:** Digital Product
**Exit criteria:** Rollout sequenced internal → limited pilot → phased → general availability, with entry/exit criteria per stage. Cohort selection, feature-flag strategy, and launch-week escalation path defined. Enablement complete for servicing, operations, and branch staff.

### Gate 6 — Post-launch and steady-state
**Owner:** Digital Product
**Exit criteria:** Review cadence set; iterate/hold/sunset criteria defined; ownership handed off from launch team to standing owner.

> **Credit Sense fast-follow items belong here as the steady-state model, not as afterthoughts:** Marketing Cloud data ingestion; additional data shared with branch staff; governance structure; rate-update mechanism; product-review and customer-alignment cadence. Writing these into the playbook is what prevents the add-on from becoming an orphan once the launch team disperses.

---

## 5. Measurement

Success is defined before launch, not after. Capture the baseline at Gate 4 so the post-launch review is an evaluation rather than a rationalization.

Define, per launch:
- **Activation** — customers entering the add-on after exposure
- **Engagement** — meaningful interaction (e.g., offer views, score checks)
- **Downstream outcome** — the business result that justified the add-on (e.g., product conversion attributable to the feature)
- **Operational load** — support-ticket volume and deflection

> **Credit Sense gap:** The current plan names Marketing Cloud ingestion and a product-review cadence but no pre-launch success measure. Define the activation, engagement, and downstream-conversion metrics and capture their baseline before go-live.

---

## 6. Templates

Maintain these as reusable artifacts appended to this document:
- Intake scorecard (Gate 0)
- Three-party RACI grid (Section 3)
- Per-gate go/no-go checklist
- Success-metric definition sheet with baseline capture (Section 5)

---

## 7. Revision log

| Date | Change | By |
|---|---|---|
| _[date]_ | Initial working draft; Credit Sense as worked example | _[name]_ |

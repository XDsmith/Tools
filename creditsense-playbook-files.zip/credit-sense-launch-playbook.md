# Credit Sense — Launch Readiness Playbook

**Platform:** Fiserv XD · **Partner:** SavvyMoney · **Release owner:** Digital Product & Experience
**Status:** Working document · **Last reviewed:** _[date]_

---

### How to use this document

This is the master readiness tracker. Each workstream owner maintains their section. Detailed artifacts are **linked, not embedded** — see the Supporting Documents register at the end. Section 3 (Readiness) and Section 10 (Launch) roll up into the single go/no-go decision.

**Status legend:** `Complete` · `Active` · `Open` (needed, not started) · `Planned` (fast-follow) · `N/A`

---

## 1. Overview

| Item | Notes | Owner | Status |
|---|---|---|---|
| Purpose | Give customers credit-score visibility and financial-wellness guidance, delivered by SavvyMoney inside Fiserv XD | Product | Active |
| Business problem | _[Define: engagement, cross-sell of credit products, retention — quantify the gap this closes]_ | Product | Open |
| Success metrics (KPIs/OKRs) | Activation, engagement, downstream conversion, operational load — **not yet defined or baselined** | Product / Data | Open |
| Executive summary | _[One paragraph for leadership]_ | Product | Open |
| Release owner | Digital Product & Experience | Product | Complete |
| Timeline | _[Milestones and go-live date]_ | Product | Open |

> **Priority gap:** success metrics and their pre-launch baseline. Cheap to capture now, expensive to reconstruct after go-live.

## 2. Product

| Item | Notes | Owner | Status |
|---|---|---|---|
| Feature overview | SavvyMoney Credit Sense: score, report factors, monitoring, pre-qualified offers | Product | Active |
| Customer value proposition | _[Draft — avoid marketing language; state the concrete benefit]_ | Product | Open |
| Personas | Tie to eligibility bands and credit-profile segments defined in discovery | Product / Design | Active |
| Customer journey | Mapped in discovery, including customer communications | Design | Complete |
| Screens / UI | Rendering within XD; confirm design-system conformance | Design | Active |
| Known limitations | _[Vendor constraints, XD rendering constraints, data-refresh cadence]_ | Product / Eng | Open |
| Dependencies | SavvyMoney (data/functionality), Fiserv XD (platform), Marketing Cloud (downstream) | Product | Active |

## 3. Readiness

| Item | Notes | Owner | Status |
|---|---|---|---|
| Business readiness checklist | Rolls up sections 4–8 | Product | Active |
| Technical readiness | Integration verified end to end incl. rate/offer sourcing | Engineering | Open |
| Operational readiness | Servicing and branch operations prepared | Operations | Open |
| Security review | Vendor and data-flow security assessment | Security | Open |
| Compliance / Legal approvals | Disclosures, fair-lending review of eligibility/thresholds, loan attributes, MIP | Compliance | Active |
| Accessibility | Conformance of the in-XD experience | Design / QA | Open |
| Performance testing | Load and availability against XD | QA | Open |

> **Fair-lending note:** credit-band thresholds and eligibility logic feed the offer determination a fair-lending review examines. Designate which compliance items are hard gates before any customer exposure.
> **Confirm Fiserv's formal certification checkpoints** and record them here as fixed gates.

## 4. Marketing

| Item | Notes | Owner | Status |
|---|---|---|---|
| Positioning | _[Define]_ | Marketing | Open |
| Messaging | _[Aligned to approved disclosures]_ | Marketing | Open |
| Email campaigns | _[Sequenced to launch calendar]_ | Marketing | Open |
| Website updates | _[Product page, rate/offer disclosures]_ | Marketing | Open |
| In-app messaging | Entry points within XD | Marketing / Product | Open |
| App Store updates | _[If mobile release notes required]_ | Marketing | Open |
| Branch collateral | Coordinate with branch-staff data sharing (fast-follow) | Marketing | Open |
| Social media | _[Define]_ | Marketing | Open |
| Launch calendar | Master schedule across channels | Marketing | Open |

## 5. Content

| Item | Notes | Owner | Status |
|---|---|---|---|
| UI copy | **Product copy — open pre-launch item** | Content / Product | Open |
| Help center | _[Articles]_ | Content / Support | Open |
| FAQs | Customer-facing | Content | Open |
| Product pages | _[Web]_ | Content / Marketing | Open |
| Disclosures | **Open pre-launch item — compliance-gated** | Compliance / Content | Open |
| Terms & Conditions | _[Vendor and product T&C]_ | Legal | Open |
| Error messages | _[XD + Credit Sense states]_ | Content / Eng | Open |
| Product CTA | **Open pre-launch item** | Content / Product | Open |

## 6. Support

| Item | Notes | Owner | Status |
|---|---|---|---|
| Support guide | _[Master reference]_ | Support | Open |
| Call center scripts | _[Incl. dispute/accuracy escalation to SavvyMoney]_ | Support | Open |
| Teller talking points | Ties to branch-staff data sharing | Support | Open |
| Internal FAQs | _[Staff-facing]_ | Support | Open |
| Escalation paths | Seams to SavvyMoney and Fiserv named | Support | Open |
| Known issues | _[From QA]_ | Support / QA | Open |
| Troubleshooting | _[Common failure states]_ | Support | Open |

## 7. Training

| Item | Notes | Owner | Status |
|---|---|---|---|
| Training deck | _[Core enablement]_ | Learning | Open |
| Demo videos | _[Walkthrough]_ | Learning | Open |
| Branch training | Frontline readiness | Learning | Open |
| Operations training | _[Servicing]_ | Learning | Open |
| Sales enablement | Cross-sell of pre-qualified offers | Learning / Product | Open |
| Knowledge checks | Confirm comprehension | Learning | Open |

## 8. Technology

| Item | Notes | Owner | Status |
|---|---|---|---|
| Environment readiness | _[Envs provisioned]_ | Engineering | Open |
| Release plan | _[Sequence and mechanics]_ | Engineering | Open |
| Rollback plan | Documented and tested | Engineering | Open |
| Feature flags | Cohort control for staged rollout | Engineering | Open |
| Monitoring | _[Uptime, integration health]_ | Engineering | Open |
| Logging | _[Trace across the SavvyMoney/XD seam]_ | Engineering | Open |
| Alerts | _[Thresholds and on-call]_ | Engineering | Open |
| Vendor coordination | SavvyMoney + Fiserv joint readiness | Vendor Mgmt / Eng | Active |

## 9. Analytics

| Item | Notes | Owner | Status |
|---|---|---|---|
| Events to capture | Instrumentation for activation/engagement/funnel | Data | Open |
| Dashboards | _[Launch + steady-state views]_ | Data | Open |
| Adoption metrics | Enrollment / first-use | Data | Open |
| Funnel metrics | Exposure → activation → offer → conversion | Data | Open |
| Error tracking | Client and integration errors | Data / Eng | Open |
| Customer feedback | In-product + survey capture | Data / Product | Open |
| Marketing Cloud ingestion | **Fast-follow** — data pipeline into Marketing Cloud | Data | Planned |

## 10. Launch

| Item | Notes | Owner | Status |
|---|---|---|---|
| Go / No-Go checklist | Rolls up sections 3–9 | Product | Open |
| Communications | Internal + customer launch comms | Communications | Open |
| Launch day schedule | Hour-by-hour runbook | Product | Open |
| War room contacts | Incl. SavvyMoney and Fiserv points of contact | Product | Open |
| Decision makers | Named go/no-go authority | Product | Open |
| Escalation matrix | Severity → owner → path | Product / Support | Open |

## 11. Post Launch

| Item | Notes | Owner | Status |
|---|---|---|---|
| Daily metrics | First-week close monitoring | Data | Open |
| Customer feedback | Triage and themes | Product / Support | Open |
| Defects | Tracking and prioritization | QA / Eng | Open |
| Enhancement backlog | Iterate/hold decisions | Product | Open |
| Lessons learned | Feeds the reusable playbook | Product | Open |
| 30/60/90-day review | Against defined KPIs | Product | Open |
| Governance structure | **Fast-follow** — standing ownership | Product | Planned |
| Rate-update mechanism | **Fast-follow** | Product / Vendor Mgmt | Planned |
| Branch-staff data sharing | **Fast-follow** | Product / Ops | Planned |
| Product-review & customer-alignment cadence | **Fast-follow** | Product | Planned |

---

## Supporting Documents

Linked, not embedded. Each owner maintains the source of record.

| Document | Owner | Link | Status |
|---|---|---|---|
| Product Brief | Product | _[link]_ | Open |
| UX Designs | Design | _[link]_ | Active |
| Technical Design | Engineering | _[link]_ | Open |
| Release Notes | Product | _[link]_ | Open |
| Marketing Plan | Marketing | _[link]_ | Open |
| Communication Plan | Communications | _[link]_ | Open |
| Training Guide | Learning | _[link]_ | Open |
| Support Guide | Customer Support | _[link]_ | Open |
| Risk Register | PM | _[link]_ | Open |
| Test Results | QA | _[link]_ | Open |
| Analytics Plan | Data | _[link]_ | Open |
| Legal / Compliance Sign-offs | Compliance | _[link]_ | Active |
| Vendor Checklist | Vendor Management | _[link]_ | Active |

---

## Revision log

| Date | Change | By |
|---|---|---|
| _[date]_ | Built to 11-section structure; Credit Sense status populated | _[name]_ |
